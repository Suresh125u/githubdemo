import './App.css';
import WeatherApp from './Component/WeatherApp/WeatherApp';

function App() {
  return (
    <div className="App">
      <WeatherApp/>
    </div>
  );
}

export default App;
